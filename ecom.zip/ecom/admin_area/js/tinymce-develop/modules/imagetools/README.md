This library contains image editing transformation algorithms used by both [TinyMCE](http://tinymce.com) and [Textbox.io](http://textbox.io).
