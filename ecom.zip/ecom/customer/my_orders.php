<center>
    <h1>My orders</h1>
    <p class="lead"> your orders on place </p>
    <p class="text-muted">
        if you have any questions 
    </p>
</center>
<hr>


<div class="table-responsive">
    <table class="table table-bordered table-hover">
        <thead><tr>
            <th>on :</th>
            <th>due amont :</th>
            <th>invoice no :</th>
            <th>qty:</th>
            <th>size:</th>
            <th>order date:</th>
            <th>paid/unpaid :</th>
            <th>status:</th>
        </tr></thead>
        <tbody>
            <tr>
                <th>#1</th>
                <td>$80</td>
                <td>36876567567</td>
                <td>2</td>
                <td>Large</td>
                <td>11-11-2020</td>
                <td>unpaid</td>
                <td>
                    <a href="confirm.php"  target="_blank"class="btn btn-primary btn-sm">confirm paid</a>
                </td>
            </tr>
        </tbody>
    </table>
</div>