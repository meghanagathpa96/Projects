<h1 align="center" > Change password</h1>
<form action="" method="post" >
    <div class="form-group">
        <label>Your old password:</label>
        <input type="password" name="old_pass" class="form-control" required>
    </div>
    <div class="form-group">
        <label> Your new password:</label>
        <input type="text" name="new_pass" class="form-control" required>
    </div>
    <div class="form-group">
        <label>confirm Your new password:</label>
        <input type="text" name="new_pass_again" class="form-control" required>
    </div>
    
    <div class="text-center">
        <button type="submit" name="submit" class="btn btn-primary">
           <i class="fa fa-user-md"></i> update now
            
        </button>
    </div>
</form>