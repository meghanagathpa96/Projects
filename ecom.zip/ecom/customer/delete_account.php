<center>
    <h1>Do you really want to delete the account</h1>
    <form action="" method="post">
        <input type="submit" name="yes" value="yes, i want to delete " class="btn btn-danger">
                <input type="submit" name="no" value="np, i dont want to delete " class="btn btn-primary">

    </form>
</center>