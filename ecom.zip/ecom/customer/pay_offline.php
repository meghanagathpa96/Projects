<center>
    <h1>My pay</h1>
    <p class="lead"> pay using method  </p>
    <p class="text-muted">
        if you have any questions 
    </p>
</center>    
<div class="table-responsive">
    <table class="table table-bordered table-hover table-striped">
        <thead><tr>
            <th>Bank account details:</th>
            <th>easy paisa</th>
            <th>Western union details</th>
            
        </tr></thead>
        <tbody>
           <td>Bank name :UBL | account no:18000000 | brank name : cottage | branch code : 9090</td>
           <td>NIC 9809</td>
           <td>real name : Ms Meghaa  |756547878 country: India |name :hfbdhgvh </td>
        </tbody>
    </table>
</div>